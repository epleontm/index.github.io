<!DOCTYPE html>

<html lang="en-us">
    <head>
	<meta name="generator" content="Hugo 0.51" />
		<meta charset="UTF-8">
		<meta name="viewport" content="width=device-width, initial-scale=1.0">
			<meta name="description" content="Download youtube thumbnail Images and vimeo videos of all quality. This app lets you to download HD thumbnail images for free. Just enter the URL of the video for which thumbnail needs to be saved.">
	<html>
  <head></head>
  <body class="vsc-initialized">
    <title>Team Cicada3301</title>
    <meta content="width=device-width,user-scalable=no,initial-scale=1,maximum-scale=1,minimum-scale=1" name="viewport">
    <meta content="IE=edge" http-equiv="X-UA-Compatible">
    <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Lobster">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/2.1.1/jquery.min.js"></script>
    <style>
      .loading {
        margin-top: 0;
        font-weight: 700;
        vertical-align: middle;
        line-height: 150px;
        font-size: 25px;
        text-transform: uppercase;
        background: linear-gradient(to right, red 30%, rgb(10, 60, 215) 75%);
        -webkit-background-clip: text;
        -webkit-text-fill-color: transparent;
      }

      h1 {
        background-color: #000;
        margin: 0;
        text-align: center;
        padding: 5px
      }

      a {
        color: #fff;
        text-decoration: none
      }

      tr th {
        font-tvv-name: bold;
        background-color: green;
        padding: 1px
      }

      * {
        box-sizing: border-box
      }

      @keyframes fadein {
        0% {
          opacity: 0
        }

        66% {
          opacity: 0
        }

        100% {
          opacity: 1
        }
      }

      @-webkit-keyframes fadein {
        0% {
          opacity: 0
        }

        66% {
          opacity: 0
        }

        100% {
          opacity: 1
        }
      }

      .tvv-item {
        position: relative;
        display: inline-block;
        width: 120px;
        height: 150px;
        margin: 3px;
        padding: 10px;
        border: 1px solid green z-index: 1;
        background: White;
        box-shadow: 1px 2px 2px red;
        overflow: hidden;
        border-radius: 4px;
        filter: contrast(100%)
      }

      .tvv-item>* {
        margin: 0;
        padding: 0
      }

      .tvv-item .tvv-thumb {
        width: 100%;
        bottom: 10px;
        top: 0px;
        position: absolute;
        right: 0;
        float: center;
      }

      .tvv-item .tvv-thumb img {
        width: 100%;
        pointer-events: none
      }

      .tvv-item .tvv-name {
        position: absolute;
        left: 0;
        bottom: 0;
        font-size: 12px;
        display: block;
        text-align: center;
        width: 100%;
        color: black;
        padding: 5px;
        font-weight: 800;
        text-overflow: ellipsis;
        black-space: nowrap;
        overflow: hidden;
        background: linear-gradient(to bottom left, #ccffff 7%, #ffffff 100%);
        box-shadow: inset 2px 2px 2px 0px rgba(255, 255, 255, .5);
        7px 7px 20px 0px rgba(0, 0, 0, .1),
        4px 4px 5px 0px rgba(0, 0, 0, .1);
        transition: all 0.3s ease;
      }

      .tvv-item img {
        width: 100%;
        pointer-events: none
      }

      .tvv-item:after {
        position: absolute;
        content: "";
        width: 100%;
        height: 0;
        top: 0;
        left: 0;
        z-index: -1;
        border-radius: 5px;
        border: 0px solid green;
        background-color: black;
        background-image: linear-gradient(to bottom left, #ccffff 7%, #ffffcc 100%);
        box-shadow: inset 2px 2px 2px 0px rgba(255, 255, 255, .5);
        7px 7px 20px 0px rgba(0, 0, 0, .1),
        4px 4px 5px 0px rgba(0, 0, 0, .1);
        transition: all 0.3s ease;
      }

      .tvv-item:hover {
        color: #000;
      }

      .tvv-item:hover:after {
        top: auto;
        bottom: 0;
        height: 100%;
      }

      .tvv-item:active {
        top: 5px;
      }

      .tvv-name:hover {}

      .fin {
        width: 100%;
        margin-top: 1px;
        margin-bottom: 2px;
        float: center;
        height: 30px;
        font-size: small;
        background-color: rgb(40, 40, 40);
        color: black;
        border-radius: 10px;
        border: 3px solid greenoutline: none;
        text-align: center;
        font-family: "Poppins", sans-serif;
      }

      .fin,
      .dftr {
        width: 100%;
        margin-top: 1px;
        margin-bottom: 2px;
        float: center;
        height: 30px;
        font-style: bold;
        background-color: rgb(40, 40, 40);
        color: purple;
        background: linear-gradient(135deg, snow 0%, seashell 64%);
        border-radius: 0px;
        border: 2px solid red;
        outline: none;
        text-align: center;
        font-family: "Poppins", sans-serif;
      }

      .fin:hover,
      .dftr:hover {
        border: 3px solid rgb(255, 60, 140);
        color: red;
        background: linear-gradient(135deg, azure 0%, floralwhite 64%);
      }

      .tvv-item {
        width: calc(100%/20 - 10px)
      }
      }

      @media only screen and (max-width:2600px) {
        .tvv-item {
          width: calc(100%/19 - 10px)
        }
      }

      @media only screen and (max-width:2470px) {
        .tvv-item {
          width: calc(100%/18 - 10px)
        }
      }

      @media only screen and (max-width:2340px) {
        .tvv-item {
          width: calc(100%/17 - 10px)
        }
      }

      @media only screen and (max-width:2210px) {
        .tvv-item {
          width: calc(100%/16 - 10px)
        }
      }

      @media only screen and (max-width:2080px) {
        .tvv-item {
          width: calc(100%/15 - 10px)
        }
      }

      @media only screen and (max-width:1950px) {
        .tvv-item {
          width: calc(100%/14 - 10px)
        }
      }

      @media only screen and (max-width:1820px) {
        .tvv-item {
          width: calc(100%/13 - 10px)
        }
      }

      @media only screen and (max-width:1690px) {
        .tvv-item {
          width: calc(100%/12 - 10px)
        }
      }

      @media only screen and (max-width:1560px) {
        .tvv-item {
          width: calc(100%/11 - 10px)
        }
      }

      @media only screen and (max-width:1430px) {
        .tvv-item {
          width: calc(100%/10 - 10px)
        }
      }

      @media only screen and (max-width:1300px) {
        .tvv-item {
          width: calc(100%/9 - 10px)
        }
      }

      @media only screen and (max-width:1170px) {
        .tvv-item {
          width: calc(100%/8 - 10px)
        }
      }

      @media only screen and (max-width:1040px) {
        .tvv-item {
          width: calc(100%/7 - 10px)
        }
      }

      @media only screen and (max-width:910px) {
        .tvv-item {
          width: calc(100%/6 - 10px)
        }
      }

      @media only screen and (max-width:780px) {
        .tvv-item {
          width: calc(100%/5 - 10px)
        }
      }

      @media only screen and (max-width:650px) {
        .tvv-item {
          width: calc(100%/4 - 10px)
        }
      }

      @media only screen and (max-width:520px) {
        .tvv-item {
          width: calc(100%/3 - 10px)
        }
      }

      @media only screen and (max-width:390px) {
        .tvv-item {
          width: calc(100%/2 - 10px)
        }
      }

      .custom-btn {
        width: 130px;
        height: 40px;
        color: #fff;
        border-radius: 5px;
        padding: 10px 25px;
        font-family: 'Lato', sans-serif;
        font-weight: 500;
        background: transparent;
        cursor: pointer;
        transition: all 0.3s ease;
        position: relative;
        display: inline-block;
        box-shadow: inset 2px 2px 2px 0px rgba(255, 255, 255, .5), 7px 7px 20px 0px rgba(0, 0, 0, .1), 4px 4px 5px 0px rgba(0, 0, 0, .1);
        outline: none;
      }

      .btn-11 {
        border: white;
        background: green;
        background: linear-gradient(80deg, yellow 0%, teal 100%);
        color: #fff;
        overflow: hidden;
      }

      .btn-11:hover {
        text-decoration: none;
        color: #fff;
        background-image: linear-gradient(135deg, red 0%, purple 64%);
      }

      .btn-11:before {
        position: absolute;
        content: '';
        display: inline-block;
        top: -180px;
        left: 0;
        width: 30px;
        height: 100%;
        background-color: #fff;
        animation: shiny-btn1 3s ease-in-out infinite;
      }

      .btn-11:hover {
        opacity: .7;
        color: white;
      }

      .btn-11:active {
        box-shadow: 4px 4px 6px 0 rgba(255, 255, 255, .3), -4px -4px 6px 0 rgba(116, 125, 136, .2), inset -4px -4px 6px 0 rgba(255, 255, 255, .2), inset 4px 4px 6px 0 rgba(0, 0, 0, .2);
      }

      @-webkit-keyframes shiny-btn1 {
        0% {
          -webkit-transform: scale(0) rotate(45deg);
          opacity: 0;
        }

        80% {
          -webkit-transform: scale(0) rotate(45deg);
          opacity: 0.5;
        }

        81% {
          -webkit-transform: scale(4) rotate(45deg);
          opacity: 1;
        }

        100% {
          -webkit-transform: scale(50) rotate(45deg);
          opacity: 0;
        }
      }

      @import url("https://fonts.googleapis.com/css?family=Roboto");

      @-webkit-keyframes come-in {
        0% {
          -webkit-transform: translatey(100px);
          transform: translatey(100px);
          opacity: 0;
        }

        30% {
          -webkit-transform: translateX(-50px) scale(0.4);
          transform: translateX(-50px) scale(0.4);
        }

        70% {
          -webkit-transform: translateX(0px) scale(1.2);
          transform: translateX(0px) scale(1.2);
        }

        100% {
          -webkit-transform: translatey(0px) scale(1);
          transform: translatey(0px) scale(1);
          opacity: 1;
        }
      }

      @keyframes come-in {
        0% {
          -webkit-transform: translatey(100px);
          transform: translatey(100px);
          opacity: 0;
        }

        30% {
          -webkit-transform: translateX(-50px) scale(0.4);
          transform: translateX(-50px) scale(0.4);
        }

        70% {
          -webkit-transform: translateX(0px) scale(1.2);
          transform: translateX(0px) scale(1.2);
        }

        100% {
          -webkit-transform: translatey(0px) scale(1);
          transform: translatey(0px) scale(1);
          opacity: 1;
        }
      }

      * {
        margin: 0;
        padding: 0;
      }

      html,
      body {
        background: #eaedf2;
        font-family: 'Roboto', sans-serif;
      }

      .stwBlurRainbow,
      .stwRainbow {
        position: fixed;
        width: 100%;
        bottom: 0;
        left: 0;
        right: 0;
        height: 3px;
        z-index: 23;
        background: linear-gradient(-45deg, #4086f4, #31a952, #fbbe01, #eb4132, #4086f4, #31a952, #fbbe01, #eb4132);
        background-size: 200%;
        -webkit-animation: animeBar 5s linear infinite;
        animation: animeBar 5s linear infinite
      }

      .stwBlurRainbow {
        height: 10px;
        z-index: 22;
        filter: blur(10px);
        opacity: .7
      }

      @-webkit-keyframes animeBar {
        0% {
          background-position: 0 50%
        }

        50% {
          background-position: 100% 50%
        }

        100% {
          background-position: 0 50%
        }
      }

      @keyframes animeBar {
        0% {
          background-position: 0 50%
        }

        50% {
          background-position: 100% 50%
        }

        100% {
          background-position: 0 50%
        }
      }
    </style>
    <center>
      <button class="btn-11 custom-btn" style="width:100%;font-weight:100;height:60px;font-size:25px;position:top:0px;z-index:3; font-family: Lobster">YOUTUBE THUMBNAIL </button>
        <a href="https://t.me/Team_Cicada330">
  <button class="btn-11 custom-btn" style="width:100%;font-weight:100;height:60px;font-size:25px;position:top:0px;z-index:3; font-family: Lobster">
    Join Team Cicada3301
  </button>
</a>	

	
		
		  <link href='https://d33wubrfki0l68.cloudfront.net/css/89c18a0889846fb0bb087e2bfa71e9bea2bbed69/css/style.css' rel='stylesheet'/>
		<link rel="canonical" href="https://youtube-thumbnail-grabber.com/">
		
		<link rel="icon" type="image/png" sizes="32x32" href="https://youtube-thumbnail-grabber.com/images/favicon-32x32.png">
		<link rel="icon" type="image/png" sizes="16x16" href="https://youtube-thumbnail-grabber.com/images/favicon-16x16.png">
		<link rel="apple-touch-icon" sizes="180x180" href="https://youtube-thumbnail-grabber.com/images/apple-touch-icon.png">
	
		
		<link href="https://youtube-thumbnail-grabber.com/index.xml" rel="alternate" type="application/rss+xml" title="Download Youtube Thumbnail" />	
	</head>
	

    <body>

				

        

<main>
	


<div class='bodyContainer'>

<div class='adContainer lg-ad' style='margin-top:5px;height:75px;text-align:center;'>
  

<script async src="https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js"></script>

<ins class="adsbygoogle"
     style="display:block"
     data-ad-client="ca-pub-4440908229393438"
     data-ad-slot="8239364825"
     data-ad-format="auto"></ins>
<script>
     (adsbygoogle = window.adsbygoogle || []).push({});
</script>
</div>


              <h2>THIS A TOOL FOR DOWNLOADING</h2>
            <h6>YOUTUBE THUMNAILS</h6>
            <h6>TEAM CICADA3301</h6>
            <h6>USE THUMBNAIL WITH OWNER PERMISSIONS</h6>
          </div>
        </div>
<div class='container'>
<form class='downloadForm' onsubmit="event.preventDefault();initDownloadLinks();">
    <input aria-label='input URL ' class='form-control col-lg-6' id='inputURL' placeholder='Enter the youtube video URL here' type='url' name='url'/>
<button class='btn btn-default' id='submitButton' type='button'>Get Thumbnail of video</button>

</form>
<div style="width:100%;">
  </div>
<div id="imgListing"class='imgListing' style="width:100%;left:0px">
  <div id='topListing' style="display: none">
  <h5 class="right-click-info">Right Click and click on 'Save Image As..' to save the images.</h5>
<h5 id='hdrestext'>HD Thumbnail Image (1280x720)</h5>
<a id="hdreslink" class="download-btn">Download HD Thumbnail Image</a>
  <img id='maxres'src="" loading="eager">
  <h5 id='sdrestext'>SD Thumbnail Image (640x480)</h5>
  <a id="sdreslink" class="download-btn">Download SD Thumbnail Image</a>
<img id='sdres' src=""  loading="auto">
</div>

<div id='bottomListing' style="display: none">
<h5 id='normalrestext'>Normal Thumbnail Image (480x360)</h5>
<a id="hqreslink" class="download-btn">Download Normal Thumbnail Image(480x360)</a>
<img id='hqres' src="" loading="lazy">
<div id='extraYTImg'>
<h5>Normal Image (320x180)</h5>
<a id="mqreslink" class="download-btn">Download Normal Thumbnail Image(320x180)</a>
<img id='mqres'src="" loading="lazy">

<h5>Normal Image (120x90)</h5>
<a id="defreslink" class="download-btn">Download Normal Thumbnail Image(120x90)</a>
<img id='defres'src="" loading="lazy">
</div>
</div>
</div>
<div class='row container-fluid ' id="extension-container" style="margin-top:50px">
<div class='card text-center'>
<div class='card-body'>
<h4 class='card-title'>Extensions</h4>
<p class='card-text'>Get Firefox extension to hassle free experience of downloading thumbnails</p>

<a class='btn btn-outline-success' href='https://j.mp/3stFug0'  target="_blank"rel='noreferrer'style="display:inline"><img src="./images/1/firefox.png" alt='Firefox Extension link' style="display:inline-block">Firefox addon</a>
</img>

</div>
</div>



</div>

</div>
</div>


<script src='https://d33wubrfki0l68.cloudfront.net/js/0751a6590cf62ebcd5edc8e320750ccd1e026fe9/ytg.js' type='text/javascript'></script>

  <script>
    initFunction();
    if(window.matchMedia('(max-width: 750px)').matches){
      var width = window.innerWidth - 50;
      width = width>200?width:200;
      document.getElementsByTagName("ins")[0].style.width=width;
    }
  </script>
  <style>
  .download-btn{
    cursor:pointer;
  }
  </style>


   <script async src="https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js"></script>



		
</main>


        		<footer>
			<span>
			
			</span>
		</footer>


    </body>
        

</html>