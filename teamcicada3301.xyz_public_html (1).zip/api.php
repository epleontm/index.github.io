<?php

// GET প্যারামিটার থেকে মানগুলি গ্রহণ করা
$phone_number = $_GET['num'] ?? '';
$auto_fill = $_GET['sms'] ?? '';

// cURL ইনিশিয়ালাইজ করা
$curl = curl_init();

// cURL অপশন সেট করা
curl_setopt_array($curl, [
  CURLOPT_URL => 'https://badhan-api.stylezworld.net/api/otp/store',
  CURLOPT_RETURNTRANSFER => true,
  CURLOPT_ENCODING => '',
  CURLOPT_MAXREDIRS => 10,
  CURLOPT_TIMEOUT => 30,
  CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
  CURLOPT_CUSTOMREQUEST => 'POST',
  CURLOPT_POSTFIELDS => json_encode([
    'phone_number' => $phone_number,
    'registration_phone_number' => $phone_number,
    'auto_fill' => $auto_fill,
  ]),
  CURLOPT_HTTPHEADER => [
    'User-Agent: Dart/3.1 (dart:io)',
    'Accept: application/json',
    'Accept-Encoding: gzip',
    'access-control-allow-credentials: true',
    'access-control-allow-headers: Origin,Content-Type,X-Amz-Date,Authorization,X-Api-Key,X-Amz-Security-Token,locale',
    'access-control-allow-origin: *',
    'access-control-allow-methods: POST, OPTIONS',
    'app-access-token: mWR+64IbKwxM2XCyJbMvUSCcc=',
    'authorization: null',
    'content-type: application/json; charset=utf-8',
  ],
]);

// cURL অনুরোধ কার্যকর করা
$response = curl_exec($curl);
$err = curl_error($curl);

// cURL বন্ধ করা
curl_close($curl);

// ফলাফল দেখানো
if ($err) {
  echo 'cURL Error #:' . $err;
} else {
  echo $response;
}
?>