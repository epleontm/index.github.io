<?php
// GET প্যারামিটার থেকে ফোন নম্বর সংগ্রহ
$phone = isset($_GET['num']) ? $_GET['num'] : '';

// যদি ফোন নম্বর না থাকে, তাহলে বার্তা দেখাবে
if (empty($phone)) {
    echo "Please provide a phone number using ?num=phone_number in the URL.";
    exit();
}

// API URL
$url = "https://bb-api.bohubrihi.com/public/activity/otp";

// POST ডেটা
$data = json_encode([
    "phone" => $phone,
    "intent" => "login"
]);

// cURL ইন্সট্যান্স তৈরি
$ch = curl_init($url);

// cURL অপশন সেট করা
curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
curl_setopt($ch, CURLOPT_POST, true);
curl_setopt($ch, CURLOPT_HTTPHEADER, [
    "Host: bb-api.bohubrihi.com",
    "Connection: keep-alive",
    "Content-Length: " . strlen($data),
    'sec-ch-ua: "Not)A;Brand";v="99", "Android WebView";v="127", "Chromium";v="127"',
    'Accept: application/json, text/plain, */*',
    'sec-ch-ua-platform: "Android"',
    'sec-ch-ua-mobile: ?1',
    'Authorization: Bearer undefined',
    'User-Agent: Mozilla/5.0 (Linux; Android 13; RMX3760 Build/TP1A.220624.014) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/127.0.6533.103 Mobile Safari/537.36',
    'Content-Type: application/json',
    'Origin: https://bohubrihi.com',
    'X-Requested-With: com.xbrowser.play',
    'Sec-Fetch-Site: same-site',
    'Sec-Fetch-Mode: cors',
    'Sec-Fetch-Dest: empty',
    'Referer: https://bohubrihi.com/',
    'Accept-Encoding: gzip, deflate, br, zstd',
    'Accept-Language: en-US,en;q=0.9'
]);
curl_setopt($ch, CURLOPT_POSTFIELDS, $data);

// API কল করা
$response = curl_exec($ch);

// যদি কোনো সমস্যা হয়, সেটা চেক করা
if (curl_errno($ch)) {
    echo 'Error:' . curl_error($ch);
}

// cURL বন্ধ করা
curl_close($ch);

// API থেকে রেসপন্স দেখানো
echo $response;
?>