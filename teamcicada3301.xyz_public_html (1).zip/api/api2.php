<?php

// Check if 'phone' parameter is passed in the URL
if (isset($_GET['phone'])) {
    // Get the phone number from the URL
    $phone = $_GET['phone'];

    // API URL
    $url = "https://training.gov.bd/backoffice/api/user/sendOtp";

    // Prepare the POST data in JSON format
    $postData = json_encode(['mobile' => $phone]);

    // Set up HTTP context options for a POST request
    $options = [
        'http' => [
            'header'  => "Content-Type: application/json\r\n",
            'method'  => 'POST',
            'content' => $postData,
        ],
    ];

    // Create a stream context
    $context = stream_context_create($options);

    // Make the request
    $response = file_get_contents($url, false, $context);

    // Check if the response was successful
    if ($response === FALSE) {
        echo "Failed to send OTP.";
    } else {
        // Output the response from the API
        echo "Response from API: " . $response;
    }
} else {
    echo "Phone number not provided.";
}

?>
