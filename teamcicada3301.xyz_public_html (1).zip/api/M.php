<?php
// Get the phone number from the query parameter
if(isset($_GET['phone'])) {
    $phone = $_GET['phone'];
    
    // API URL
    $url = 'https://training.gov.bd/backoffice/api/user/sendOtp';
    
    // Data to be sent via POST
    $data = array('mobile' => $phone);
    
    // Initialize cURL session
    $ch = curl_init($url);
    
    // Convert data to JSON
    $payload = json_encode($data);
    
    // Set cURL options
    curl_setopt($ch, CURLOPT_POSTFIELDS, $payload);
    curl_setopt($ch, CURLOPT_HTTPHEADER, array('Content-Type:application/json'));
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    
    // Execute the cURL request and get the response
    $response = curl_exec($ch);
    
    // Close the cURL session
    curl_close($ch);
    
    // Output the response
    echo $response;
} else {
    echo "Phone number is missing";
}
?>
