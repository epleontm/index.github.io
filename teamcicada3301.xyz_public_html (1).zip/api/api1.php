<?php
// Get the phone number from the query parameters
$phone = isset($_GET['phone']) ? $_GET['phone'] : '';
$otp_type = 'login'; // Since OTP type is fixed as 'login'

// Check if the phone number is provided
if (!$phone) {
    echo json_encode([
        'status' => 'error',
        'message' => 'Phone number is required!'
    ]);
    exit;
}

// API URL
$url = "https://api.chardike.com/api/otp/send";

// Set up the data to be sent
$data = [
    'phone' => $phone,
    'otp_type' => $otp_type
];

// Initialize cURL
$ch = curl_init();

// Configure cURL options
curl_setopt($ch, CURLOPT_URL, $url);
curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
curl_setopt($ch, CURLOPT_POST, true);
curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($data));
curl_setopt($ch, CURLOPT_HTTPHEADER, [
    'Content-Type: application/json'
]);

// Execute the request
$response = curl_exec($ch);

// Check for errors
if ($response === false) {
    echo json_encode([
        'status' => 'error',
        'message' => 'Curl error: ' . curl_error($ch)
    ]);
} else {
    // Output the API response
    echo $response;
}

// Close the cURL session
curl_close($ch);
?>
