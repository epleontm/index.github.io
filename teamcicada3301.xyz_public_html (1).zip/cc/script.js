document.getElementById('generate-btn').addEventListener('click', function() {
    const bin = document.getElementById('bin-input').value;
    if(bin) {
        let cardsHtml = '';
        for (let i = 0; i < 10; i++) {
            const cardNumber = `${bin}${Math.floor(Math.random() * 100000000000)}`.slice(0, 16);
            const cvv = Math.floor(Math.random() * 900) + 100;
            const expiryDate = `${Math.floor(Math.random() * 12) + 1}/${new Date().getFullYear() + 3}`;
            
            cardsHtml += `
                <div class="card-info">
                    <p>Card Number: <strong>${cardNumber}</strong> <button class="copy-btn" data-clipboard-text="${cardNumber}">📋</button></p>
                    <p>CVV: <strong>${cvv}</strong> <button class="copy-btn" data-clipboard-text="${cvv}">📋</button></p>
                    <p>Expiry Date: <strong>${expiryDate}</strong> <button class="copy-btn" data-clipboard-text="${expiryDate}">📋</button></p>
                </div>
            `;
        }
        document.getElementById('result').innerHTML = cardsHtml;

        // Add copy functionality
        document.querySelectorAll('.copy-btn').forEach(button => {
            button.addEventListener('click', function() {
                const textToCopy = this.getAttribute('data-clipboard-text');
                navigator.clipboard.writeText(textToCopy).then(() => {
                    alert('Copied: ' + textToCopy);
                });
            });
        });
    } else {
        alert('Please enter a BIN number.');
    }
});