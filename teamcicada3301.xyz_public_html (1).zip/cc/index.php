<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="style.css">
    <title>Live BIN CC Maker</title>
</head>
<body>
    <header>
        <h1>Live BIN CC Maker</h1>
    </header>
    <main>
        <div class="container">
            <input type="text" id="bin-input" placeholder="Enter BIN Number">
            <button id="generate-btn">Generate Cards</button>
        </div>
        <div id="result" class="result">
            <!-- Generated card information will appear here -->
        </div>
    </main>
    <footer>
        <p>Developed By: Team Cicada3301 | <a href="https://t.me/Team_Cicada330">Contact</a></p>
    </footer>
    <script src="script.js"></script>
</body>
</html>