<?php
// api_config.php
$api_url = 'https://smmgen.com/api/v2'; // API website URL
$api_key = 'd4b4bd93b9dff22da0485c08d63229d7'; // Your API key
$service_id = 9236; // Default service ID
?>